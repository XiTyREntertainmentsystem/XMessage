if (target) {
                    target.ws.send(JSON.stringify({
                        type: 'file',
                        from: userId,
                        name: data.name,
                        data: data.data,
                        sender: data.sender
                    }));
                    console.log(`\x1b[33m📎 Файл от ${userId} к ${data.to}: ${data.name}\x1b[0m`);
                } else {
                    console.log(`\x1b[31m❌ Файл от ${userId} к ${data.to}: получатель не в сети\x1b[0m`);
                }
            }
        } catch(e) {
            console.log('Ошибка:', e);
        }
    });

    ws.on('close', () => {
        if (userId) {
            clients.delete(userId);
            console.log(`\x1b[31m❌ Пользователь отключился: ${userId} (${clientVersion || 'unknown'})\x1b[0m`);
            broadcastOnlineUsers();
        }
    });
});

function broadcastOnlineUsers() {
    const online = Array.from(clients.keys());
    const usersInfo = Array.from(clients.entries()).map(([id, data]) => ({ id, version: data.version }));
    const message = JSON.stringify({ type: 'online_users', users: online, usersInfo: usersInfo });
    clients.forEach((client) => {
        if (client.ws.readyState === WebSocket.OPEN) {
            client.ws.send(message);
        }
    });
}

const os = require('os');
const interfaces = os.networkInterfaces();
let localIp = 'localhost';
for (const name of Object.keys(interfaces)) {
    for (const net of interfaces[name]) {
        if (net.family === 'IPv4' && !net.internal && net.address.startsWith('192.168.')) {
            localIp = net.address;
            break;
        }
    }
}

console.log(`\x1b[32m✅ Сервер ${SERVER_NAME} запущен на порту 8080\x1b[0m`);
console.log(`\x1b[33m📱 Адрес для подключения: ws://${localIp}:8080\x1b[0m`);
console.log(`\x1b[36m💡 Ожидание подключений...\x1b[0m`);
console.log('');